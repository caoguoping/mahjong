
function girl.gc()
    cc.Director:getInstance():purgeCachedData()
end